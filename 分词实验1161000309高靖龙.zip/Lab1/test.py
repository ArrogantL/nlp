import gc
if __name__ == '__main__':
    print("12345"[3:])